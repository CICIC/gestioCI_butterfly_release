- pip install django1.7 
 info >> https://wiki.enredaos.net/index.php?title=GestioCI-Codi#django_1.7
- pip install Image
- pip install django-cron
- pip install django-csvimport 
 patch >> https://wiki.enredaos.net/index.php?title=CICICdev/september#csv-import
- pip install django-localflavor 
 patch >> https://github.com/django/django-localflavor/commit/8378b768d348fe682310e9add8531dd77465aaf8
- easy_install xhtml2pdf 
 ( ReportLab Toolkit, HTML5lib, pyPdf y PIL ) 
- pip install django-mptt
- pip install django-mptt-admin 

