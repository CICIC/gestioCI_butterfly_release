<?php

header("Location: https://gestio.cooperativa.cat");

?>
